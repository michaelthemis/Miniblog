<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Registration</title>
</head>
<style>
	body{
		padding: 150px;
		text-align: center;
	}
	.container{
		max-width: 600px;
		margin: 0 auto;
		padding: 50px;
		text-align: left;
		box-shadow: rgba(100,100,111,0.2) 0px 7px 29px 0px;
	}
	.formgroup {
		margin-bottom: 300px;
	}
	input[type=text] {
		width: 100%;
  		padding: 12px 20px;
  		margin: 8px 0;
  		box-sizing: border-box;
		border-radius: 4px;
		border-style: hidden hidden solid hidden;
		margin-top:10px;
		margin-bottom: 30px;
	}
	input[type=submit] {
		color: #fff;
		background: #32a88f;
		width: 30%;
  		padding: 12px 20px;
  		margin: 8px 0;
		margin-bottom: 20px;
  		box-sizing: border-box;
		font-weight: bold;
		border-radius: 4px;
		border-style: hidden;
		box-shadow: rgba(100,100,111,0.2) 0px 7px 29px 0px;
	}
	input[type=submit]:hover {
		background-color: #fff;
		color: black;
		cursor:pointer;
		transition: 0.3s;
	}
    input[type=button] {
		color: #fff;
		background: #32a88f;
		width: 30%;
  		padding: 12px 20px;
  		margin: 8px 0;
		margin-bottom: 20px;
  		box-sizing: border-box;
		font-weight: bold;
		border-radius: 4px;
		border-style: hidden;
		box-shadow: rgba(100,100,111,0.2) 0px 7px 29px 0px;
	}
	input[type=button]:hover {
		background-color: #fff;
		color: black;
		cursor:pointer;
		transition: 0.3s;
	}
	a.return {
		color: orange;
		font-weight: bold;
		font-size: 0.8rem;
	}
	p {
		margin-bottom: 20px;
		font-weight: bold;
		font-size: 1.5rem;
	}
</style>
<body>
	<?php include 'Navbar.php' ?>
    <?php
	if(isset($_POST["Login"]))
	{
        $email = $_POST["email"];
        $password = $_POST["password"];

            require_once "database.php";
            $sql = "SELECT * FROM user WHERE email = '$email'";
            $result = mysqli_query($conn, $sql);
            $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
            if ($user) {
            if (password_verify($password, $user["password"]))
            {
                header("Location: Dashboard.php");
                die();
            }
            else
            {
                echo "<div class='alert alert-danger'>Password does not match.</div>";
            }
            } 
            else 
            {
                echo "<div class='alert alert-danger'>Email does not exist</div>";
            }
    }

    ?>
	<div class="container">
		<form method="post">
			<a>Login</a>
			<div class="form-group">
					<input type="text" class="form-control" name="email" placeholder="Enter Email">
			</div>
			<div class="form-group">
					<input type="text" class="form-control" name="password" placeholder="Enter Password">
			</div>
			<div class="form-group">
                    <input type="submit" class="Log" value="Login" name="Login">
					<input type="submit" class="Reg" value="Register" name="Register" formaction="Registration.php">
			</div>
			Currently logged out.
		</form>
	</div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Registration</title>
	<!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">-->
</head>
<style>
	body{
		padding: 150px;
		text-align: center;
	}
	.container{
		max-width: 600px;
		margin: 0 auto;
		padding: 50px;
		text-align: left;
		box-shadow: rgba(100,100,111,0.2) 0px 7px 29px 0px;
	}
	.formgroup {
		margin-bottom: 300px;
	}
	input[type=text] {
		width: 100%;
  		padding: 12px 20px;
  		margin: 8px 0;
  		box-sizing: border-box;
		border-radius: 4px;
		border-style: hidden hidden solid hidden;
		margin-top:10px;
		margin-bottom: 30px;
	}
	input[type=submit] {
		color: #fff;
		background: #32a88f;
		width: 30%;
  		padding: 12px 20px;
  		margin: 8px 0;
		margin-bottom: 20px;
  		box-sizing: border-box;
		font-weight: bold;
		border-radius: 4px;
		border-style: hidden;
		box-shadow: rgba(100,100,111,0.2) 0px 7px 29px 0px;
	}
	input[type=submit]:hover {
		background-color: #fff;
		color: black;
		cursor:pointer;
		transition: 0.3s;
	}
	a.return {
		color: orange;
		font-weight: bold;
		font-size: 0.8rem;
	}
	p {
		margin-bottom: 20px;
		font-weight: bold;
		font-size: 1.5rem;
	}
</style>
<body>
	<?php include 'Navbar.php' ?>
	<p>Registration</p>
	<?php
	if(isset($_POST["submit"]))
	{
		$username = $_POST["username"];
		$email = $_POST["email"];
		$password = $_POST["password"];
		$passwordRepeat = $_POST["repeat_password"];

		$passwordHash = password_hash($password, PASSWORD_DEFAULT);
		
		$errors = array();
		
		if(empty($username) OR empty($email) OR empty($password) OR empty($passwordRepeat))
		{
			array_push($errors, "All fields are required");
		}
		if(!filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			array_push($errors, "Email is not Valid");
		}
		if(strlen($password)<8)
		{
			array_push($errors, "Password must be at least 8 characters long");
		}
		if($password!==$passwordRepeat)
		{
			array_push($errors,"Password does not match");
		}

		require_once "database.php";
		$sql = "SELECT * FROM user WHERE username = '$username'";
		$result = mysqli_query($conn, $sql);
		$rowCount = mysqli_num_rows($result);
		if ($rowCount>0) {
			array_push($errors, "Username already exists");
		}

		require_once "database.php";
		$sql = "SELECT * FROM user WHERE email = '$email'";
		$result = mysqli_query($conn, $sql);
		$rowCount = mysqli_num_rows($result);
		if ($rowCount>0) {
			array_push($errors, "Email already exists");
		}

		if (count($errors)>0) 
		{
			foreach ($errors as $error) 
			{
				echo "<div class='alert alert-danger'>$error<>";
			} 
		}
		else
			{
			//will insert data when no errors
			require_once "database.php";
			$sql = "INSERT INTO user (username, email, password) VALUES ( ?, ?, ? )";
			$stmt = mysqli_stmt_init($conn);
			$prepareStmt = mysqli_stmt_prepare($stmt, $sql);
			if ($prepareStmt) {
				mysqli_stmt_bind_param($stmt, "sss", $username, $email, $passwordHash);
				mysqli_stmt_execute($stmt);
				echo "<div class= 'alert alert-success'>You are registered successfully.<div>";
			}
			else{
				die("Something went wrong");
			}
		}
		
	}
	?>
	<div class="container">
		<form method="post">
			<a href="#">See the Registration Rules</a>
			<div class="form-group">
					<input type="text" class="form-control" name="username" placeholder="Enter Username">
			</div>
			<div class="form-group">
					<input type="text" class="form-control" name="email" placeholder="Enter Email">
			</div>
			<div class="form-group">
					<input type="text" class="form-control" name="password" placeholder="Enter Password">
			</div>
			<div class="form-group">
					<input type="text" class="form-control" name="repeat_password" placeholder="Confirm Password">
			</div>
			<div class="form-group">
					<input type="submit" value="Register" name="submit">
			</div>
			return to<a class="return" href ="Login.php"> LOGIN PAGE</a>
		</form>
	</div>
</body>
</html>
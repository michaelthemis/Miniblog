<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <style>
    body{
		padding: 150px;
		text-align: center;
	}
    </style>
    <body>
    <?php include 'UserNav.php' ?>
    <h1>You have successfully logged in!</h1>
        <script src="" async defer></script>
    </body>
</html>